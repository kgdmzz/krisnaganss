# B1GT0ken
B1GT0ken Bot

Menggunakan = mengerti.

