<?php
/**
 * @author fb.com/www.zeldin.go.id
 * @package B1GT0ken
**/
require "./lib.php";
$reff = "ZM654CIID"; // REFF
$serverMail = 1; // Server Generate Mail select 1 or 0
echo "[!] STARTED... GENERATING MAIL\n";
if($serverMail == 1){
	require "./gen.php";
	include("./v2.php");
}else{
	require "./temp.php";
	include("./v1.php");
}
?>
